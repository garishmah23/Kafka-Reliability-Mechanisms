package com.example.Kafka.reliability;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaReliabilityApplicationTests {

	@Test
	void contextLoads() {
	}

}
